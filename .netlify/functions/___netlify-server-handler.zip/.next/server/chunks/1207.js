"use strict";exports.id=1207,exports.ids=[1207],exports.modules={1207:(e,t,r)=>{r.r(t),r.d(t,{default:()=>Document});var n=r(997),s=r(6859),o=r(4298),a=r.n(o);function Document(){return(0,n.jsxs)(s.Html,{children:[(0,n.jsxs)(s.Head,{children:[" ",n.jsx(a(),{id:"partnero-universal",strategy:"afterInteractive",dangerouslySetInnerHTML:{__html:`
            (function(p,t,n,e,r,o){ 
              p['__partnerObject']=r;
              function f(){
                var c={ a:arguments,q:[]};
                var r=this.push(c);
                return "number"!=typeof r?r:f.bind(c.q);
              }
              f.q=f.q||[];
              p[r]=p[r]||f.bind(f.q);
              p[r].q=p[r].q||f.q;
              o=t.createElement(n);
              var _=t.getElementsByTagName(n)[0];
              o.async=1;
              o.src=e+'?v'+(~~(new Date().getTime()/1e6));
              _.parentNode.insertBefore(o,_);
            })(window, document, 'script', 'https://app.partnero.com/js/universal.js', 'po');
            
            po('settings', 'assets_host', 'https://assets.partnero.com');
            po('program', 'XWWZZGQN', 'load');
          `}})]}),(0,n.jsxs)("body",{children:[n.jsx(s.Main,{}),n.jsx(s.NextScript,{})]})]})}}};